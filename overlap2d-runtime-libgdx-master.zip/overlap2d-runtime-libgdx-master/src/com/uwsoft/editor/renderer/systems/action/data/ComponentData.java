package com.uwsoft.editor.renderer.systems.action.data;

import com.badlogic.ashley.core.ComponentMapper;

/**
 * Created by aurel on 19/02/16.
 */
public class ComponentData extends DelegateData {
    public ComponentMapper linkedComponentMapper;
}
