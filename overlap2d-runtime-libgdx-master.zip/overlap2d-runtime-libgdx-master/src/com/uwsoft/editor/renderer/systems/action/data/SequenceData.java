package com.uwsoft.editor.renderer.systems.action.data;

/**
 * Created by ZeppLondon on 10/23/15.
 */
public class SequenceData extends ParallelData {
    public int index;


    public SequenceData(ActionData[] actionDatas) {
        super(actionDatas);
    }
}
