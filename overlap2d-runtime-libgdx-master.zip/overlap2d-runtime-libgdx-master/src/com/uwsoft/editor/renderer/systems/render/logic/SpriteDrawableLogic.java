package com.uwsoft.editor.renderer.systems.render.logic;

import com.badlogic.ashley.core.Entity;
import com.badlogic.gdx.graphics.g2d.Batch;

public class SpriteDrawableLogic extends TexturRegionDrawLogic {

	@Override
	public void draw(Batch batch, Entity entity, float parentAlpha) {
		super.draw(batch, entity, parentAlpha);
		//TODO in case we need specific things 
	}

}
