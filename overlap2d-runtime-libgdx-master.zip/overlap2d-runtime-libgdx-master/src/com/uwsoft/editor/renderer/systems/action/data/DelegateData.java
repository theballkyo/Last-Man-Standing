package com.uwsoft.editor.renderer.systems.action.data;

/**
 * Created by ZeppLondon on 10/15/2015.
 */
public class DelegateData extends ActionData {
    public DelegateData() {
        super();
    }
}
