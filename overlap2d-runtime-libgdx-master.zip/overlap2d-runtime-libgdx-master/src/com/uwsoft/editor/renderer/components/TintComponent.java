package com.uwsoft.editor.renderer.components;

import com.badlogic.ashley.core.Component;
import com.badlogic.gdx.graphics.Color;

public class TintComponent implements Component {
	public Color color = new Color();
}
