package com.uwsoft.editor.renderer.components.spriter;

import com.badlogic.ashley.core.Component;
import com.uwsoft.editor.renderer.utils.LibGdxDrawer;

public class SpriterDrawerComponent implements Component {
	public LibGdxDrawer drawer;
}
