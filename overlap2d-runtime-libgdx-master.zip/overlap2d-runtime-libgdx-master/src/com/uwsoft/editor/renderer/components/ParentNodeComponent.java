package com.uwsoft.editor.renderer.components;

import com.badlogic.ashley.core.Component;
import com.badlogic.ashley.core.Entity;

public class ParentNodeComponent implements Component {
	public Entity parentEntity = null;
}
