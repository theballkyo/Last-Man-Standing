package com.uwsoft.editor.renderer.components;

import com.badlogic.ashley.core.Component;

public class SpineDataComponent implements Component {
	public String animationName = "";
	public String currentAnimationName = "";
}
