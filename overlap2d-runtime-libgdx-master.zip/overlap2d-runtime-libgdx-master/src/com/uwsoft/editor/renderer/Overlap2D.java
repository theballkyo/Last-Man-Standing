package com.uwsoft.editor.renderer;

import java.lang.annotation.Retention;
import static java.lang.annotation.RetentionPolicy.*;

public @Retention(RUNTIME) @interface Overlap2D {

}
